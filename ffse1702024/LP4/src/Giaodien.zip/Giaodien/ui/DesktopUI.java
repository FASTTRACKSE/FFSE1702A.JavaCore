package Giaodien.ui;

import java.awt.Container;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.BoxLayout;
import javax.swing.DefaultComboBoxModel;
import javax.swing.ImageIcon;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.table.DefaultTableModel;

import com.mysql.jdbc.PreparedStatement;

public class DesktopUI extends JFrame {
	private Connection connect = null;
	private JTable jtable = new JTable();
	
	private DefaultTableModel tableModel = new DefaultTableModel();
	private JButton btn_Add, btn_Edit, btn_Dele, btn_Save;
	JTextField maSV, tenSV, tuoiSV,nha,dienthoai,email;
	String country[] = { "FFSE1702-A", "FFSE1702", "FFSE1703", "FFSE1704" };

	 JComboBox jcomboClass = new JComboBox(country);
	 JPanel boxa = new JPanel();
	JLabel ab = new JLabel("Lớp :         ");
	
	JPanel boxb = new JPanel();
	
	JLabel tinh = new JLabel("Tỉnh(TP) :     ");
	JComboBox jcomboTinh = new JComboBox();
	JPanel boxc = new JPanel();
	JLabel huyen = new JLabel("Huyện(Quận) :     ");
	JComboBox jcomboHuyen = new JComboBox();
	
	JLabel xa = new JLabel("Xã(Phường) :     ");
	JComboBox jcomboXa = new JComboBox();
	
	public DesktopUI(String title) {
		super(title);
		createGUI();
		addEvents();
		
	}
	private void createGUI() {
		add(createTabbedPane());
	}

	private JTabbedPane createTabbedPane() {
		

		Container con = getContentPane();
		JPanel boxAll = new JPanel();
		boxAll.setLayout(new BoxLayout(boxAll, BoxLayout.Y_AXIS));

		con.add(boxAll);
		JPanel boxa = new JPanel();
		JLabel ab = new JLabel("Lớp :     ");

		JPanel box1 = new JPanel();
		JLabel a = new JLabel("Mã sinh viên :     ");
		 maSV = new JTextField(20);
		box1.add(a);
		box1.add(maSV);

		JPanel box2 = new JPanel();
		JLabel a1 = new JLabel("Tên sinh viên :  ");
		 tenSV = new JTextField(20);
		box2.add(a1);
		box2.add(tenSV);

		JPanel box3 = new JPanel();
		JLabel a2 = new JLabel("Tuổi sinh viên : ");
		 tuoiSV = new JTextField(20);
		box3.add(a2);
		box3.add(tuoiSV);

		JPanel box4 = new JPanel();
		JLabel a3 = new JLabel("Số nhà :         ");
		 nha = new JTextField(20);
		box4.add(a3);
		box4.add(nha);

		JPanel box5 = new JPanel();
		JLabel a4 = new JLabel("Điện thoại :       ");
		 dienthoai = new JTextField(20);
		box5.add(a4);
		box5.add(dienthoai);

		JPanel box6 = new JPanel();
		JLabel a5 = new JLabel("Email :           ");
		 email = new JTextField(20);
		box6.add(a5);
		box6.add(email);

		JPanel box7 = new JPanel();
		JLabel a11 = new JLabel("Tìm theo tên :           ");
		JTextField text51 = new JTextField(20);
		box7.add(a11);
		box7.add(text51);

		JPanel box8 = new JPanel();
		JLabel a12 = new JLabel("Tìm theo mã sinh viên :           ");
		JTextField text52 = new JTextField(20);
		box8.add(a12);
		box8.add(text52);

		JButton timkiem = new JButton("Tìm");

		 btn_Add = new JButton("ADD");
		 btn_Edit = new JButton("EDIT");
		 btn_Dele = new JButton("DELE");
		 btn_Save = new JButton("SAVE");

		JPanel panelall = new JPanel();
		panelall.setLayout(new BoxLayout(panelall, BoxLayout.X_AXIS));

		JPanel panel1 = new JPanel();
		panel1.setLayout(new BoxLayout(panel1, BoxLayout.X_AXIS));

		JPanel panel11 = new JPanel();
		panel11.setLayout(new BoxLayout(panel11, BoxLayout.X_AXIS));

		JPanel panel12 = new JPanel();
		panel12.setLayout(new BoxLayout(panel12, BoxLayout.X_AXIS));

		JPanel panel2 = new JPanel();
		panel2.setLayout(new BoxLayout(panel2, BoxLayout.X_AXIS));

		JPanel panel21 = new JPanel();
		panel21.setLayout(new BoxLayout(panel21, BoxLayout.Y_AXIS));

		JPanel panel22 = new JPanel();
		panel22.setLayout(new BoxLayout(panel22, BoxLayout.Y_AXIS));

		JPanel panel221 = new JPanel();
		panel221.setLayout(new BoxLayout(panel221, BoxLayout.Y_AXIS));

		JPanel panel2a = new JPanel();
		panel221.setLayout(new BoxLayout(panel221, BoxLayout.Y_AXIS));

		JPanel panel2b = new JPanel();
		panel221.setLayout(new BoxLayout(panel221, BoxLayout.Y_AXIS));

		JPanel panel2c = new JPanel();
		panel221.setLayout(new BoxLayout(panel221, BoxLayout.Y_AXIS));

		JPanel panel222 = new JPanel();
		panel222.setLayout(new BoxLayout(panel222, BoxLayout.Y_AXIS));

		JPanel panel2221 = new JPanel();
		panel2221.setLayout(new BoxLayout(panel2221, BoxLayout.Y_AXIS));

		JPanel panel2222 = new JPanel();
		panel2222.setLayout(new BoxLayout(panel2222, BoxLayout.Y_AXIS));

		JPanel panela = new JPanel();
		panela.setLayout(new BoxLayout(panela, BoxLayout.X_AXIS));

		JPanel panelb = new JPanel();
		panelb.setLayout(new BoxLayout(panelb, BoxLayout.X_AXIS));

		JPanel panelc = new JPanel();
		panelc.setLayout(new BoxLayout(panelc, BoxLayout.X_AXIS));

		JPanel panelc1 = new JPanel();
		panelc1.setLayout(new BoxLayout(panelc1, BoxLayout.X_AXIS));
		
		JPanel panelc2 = new JPanel();
		panelc1.setLayout(new BoxLayout(panelc1, BoxLayout.X_AXIS));

		JPanel paneld = new JPanel();
		paneld.setLayout(new BoxLayout(paneld, BoxLayout.X_AXIS));

		panel11.add(box7);
		panel11.add(box8);
		panel11.add(timkiem);
		
		panela.add(box1);

		panela.add(box2);
		panelb.add(box3);
		panelb.add(box4);
		panelc.add(box5);
		panelc.add(box6);

		panelc1.add(boxa);
		panelc2.add(boxc);
		
		boxa.add(ab);
		panelc1.add(boxb);
		panelc2.add(huyen);
		panelc2.add(jcomboHuyen);
		panelc2.add(xa);
		panelc2.add(jcomboXa);
		boxa.add(jcomboClass);
		boxa.add(tinh);
		boxa.add(jcomboTinh);

		 panelc1.add(boxa);
			//panelc1.add(boxa1);
		paneld.add(btn_Add);
		paneld.add(btn_Edit);
		paneld.add(btn_Dele);
		paneld.add(btn_Save);

		jtable.setModel(tableModel);
		jtable.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
		panel21.add(jtable);
		JScrollPane scroll = JTable.createScrollPaneForTable(jtable);
		panel21.add(scroll);

		jtable.getSelectionModel().addListSelectionListener(new ListSelectionListener() {

			@Override
			public void valueChanged(ListSelectionEvent arg0) {
				int row = jtable.getSelectedRow();
				JTable model;
				maSV.setText(tableModel.getValueAt(row, 1).toString());
				tenSV.setText(tableModel.getValueAt(row, 2).toString());
				tuoiSV.setText(tableModel.getValueAt(row, 3).toString());
				nha.setText(tableModel.getValueAt(row, 5).toString());
				email.setText(tableModel.getValueAt(row, 6).toString());
				dienthoai.setText(tableModel.getValueAt(row, 7).toString());
				String lop = tableModel.getValueAt(row, 4).toString();
				jcomboClass.getModel().setSelectedItem(lop);
				
				String tinh = tableModel.getValueAt(row, 8).toString();
				jcomboTinh.getModel().setSelectedItem(tinh);
				
				String huyen = tableModel.getValueAt(row, 9).toString();
				jcomboHuyen.getModel().setSelectedItem(huyen);
				String xa = tableModel.getValueAt(row, 10).toString();
				jcomboXa.getModel().setSelectedItem(xa);
				
				
			}

		});

		boxAll.add(panel1);
		boxAll.add(panel2);
		panel1.add(panel11);
		panel1.add(panel12);
		panel2.add(panel22);
		panel2.add(panel21);

		panel2221.add(panela);
		panel2221.add(panelb);
		panel2221.add(panelc);
		panel2221.add(panelc1);
		panel2221.add(panelc2);
		panel2221.add(paneld);
		panel22.add(panel221);
		panel22.add(panel222);
		panel222.add(panel2221);
		panel222.add(panel2222);

		panel221.add(panel2a);
		panel221.add(panel2b);
		panel221.add(panel2c);

		// endTab1
		// tab2

		connectSQL(); // kết nối cơ sở dữ liệu
		updateData(view()); 
		updateDatatinh(tinh());
		updateDatahuyen(huyen());
		updateDataxa(xa());
		// gọi hàm view để truy suất dữ liệu sau đó truyền cho hàm updateData để đưa dữ
							// liệu vào tableModel và hiện lên Jtable trong Frame

		JTabbedPane tabbedPane = new JTabbedPane();
		ImageIcon img4 = new ImageIcon(
				new ImageIcon("C:\\Users\\DELL\\Documents\\GitHub\\ffse1702a.javacore\\ffse1702024\\sv1.png").getImage()
						.getScaledInstance(100, 80, Image.SCALE_SMOOTH));
		

		tabbedPane.addTab("", img4, boxAll, "Quản lí Sinh Viên");
		tabbedPane.addTab("", img4, boxAll, "Quản lí Sinh Viên");

		tabbedPane.addTab("", img4, boxAll, "Quản lí Sinh Viên");

		tabbedPane.setTabPlacement(JTabbedPane.LEFT);

				
		return tabbedPane;

	}


	ActionListener eventAdd = new ActionListener() {
		public void actionPerformed(ActionEvent arg0) {
			addInfo();
		}
	};
		public void addInfo() {
				String mssv = maSV.getText();
				String age = tuoiSV.getText();
				String adress = nha.getText();
				String name = tenSV.getText();
				String sdt = dienthoai.getText();
				String lop = (String) jcomboClass.getSelectedItem();
				String mail = email.getText();
				String tinh = (String) jcomboTinh.getSelectedItem();
				
				String huyen = (String) jcomboHuyen.getSelectedItem();
				
				String xa = (String) jcomboXa.getSelectedItem();

				DefaultTableModel TableModel = (DefaultTableModel) jtable.getModel();
				TableModel.addRow(new Object[] { "ID", mssv,name,age,lop,adress,mail,sdt,tinh,huyen,xa });
				maSV.setText("");
				nha.setText("");
				tenSV.setText("");
				
				email.setText("");
				dienthoai.setText("");

				try {

					String sql = "INSERT INTO `sinhvien` (`maSV`, `tenSV`, `tuoiSV`, `lop`, `nha`, `email`, `dienthoai`, `tinh`, `huyen`, `xa`)"
							+ " VALUES ('" + mssv + "', '" + name + "', '" + age + "', '" + lop + "', '" + adress + "', '" + mail + "', '" + sdt + "', '" + tinh + "', '" + huyen + "', '" + xa + "')";
					Statement statement = connect.createStatement();
					int x = statement.executeUpdate(sql);
					if (x > 0) {
						JOptionPane.showMessageDialog(null, "Lưu OK");
					}
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		
	public void addEvents() {
		btn_Add.addActionListener(eventAdd);
//		btn_Edit.addActionListener(evUpdate);
//		btn_Dele.addActionListener(evInsert);
//		btn_Save.addActionListener(evDelete);
		
	}

	public void updateData(ResultSet result) {
		String[] colsName = { "ID","Mã SV", "Họ Tên", "Tuổi", "Lớp", "Địa Chỉ", "Email", "SĐT","Tỉnh","Huyện","Xã" };
		tableModel.setColumnIdentifiers(colsName); // Đặt tiêu đề cho bảng theo các giá trị của mảng colsName

		try {
			while (result.next()) { // nếu còn đọc tiếp được một dòng dữ liệu
				String rows[] = new String[11];
				rows[0] = result.getString(1);
				rows[1] = result.getString(2);
				rows[2] = result.getString(3);
				rows[3] = result.getString(4);
				rows[4] = result.getString(5);
				rows[5] = result.getString(6);
				rows[6] = result.getString(7);
				rows[7] = result.getString(8);
				rows[8] = result.getString(9);
				rows[9] = result.getString(10);
				rows[10] = result.getString(11);

				tableModel.addRow(rows); // đưa dòng dữ liệu vào tableModel để hiện thị lên

				// mỗi lần có sự thay đổi dữ liệu ở tableModel thì Jtable sẽ tự động update lại
				// trên frame
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}

	public void connectSQL() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			String url = new String("jdbc:mysql://localhost:3306/quangnc1?useUnicode=true&characterEncoding=utf-8");
			try {
				connect = DriverManager.getConnection(url, "quangnc1", "abc123");

			} catch (SQLException e) {
				e.printStackTrace();
			}
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		}

	}

	public ResultSet view() {
		ResultSet result = null;
		String sql = "SELECT * FROM sinhvien";
		try {
			Statement statement = (Statement) connect.createStatement();
			return statement.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return result;
		
	}
	public void updateDatatinh(ResultSet resulttinh) {
		Vector<String> data = new Vector<String>();
		try {
			while (resulttinh.next()) {
			data.addElement(resulttinh.getString(1));
			jcomboTinh.setModel(new DefaultComboBoxModel<>(data));
				
			}} 
			catch (SQLException e) {
				e.printStackTrace();
			}

		}
	public ResultSet tinh() {
		
		ResultSet resulttinh = null;
		String sql = "SELECT name FROM devvn_tinhthanhpho";
		try {
			Statement statement = (Statement) connect.createStatement();
			return statement.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resulttinh;
	}
	
	public void updateDatahuyen(ResultSet resulthuyen) {
		Vector<String> datahuyen = new Vector<String>();
		try {
			while (resulthuyen.next()) {
			datahuyen.addElement(resulthuyen.getString(1));
			jcomboHuyen.setModel(new DefaultComboBoxModel<>(datahuyen));
				
			}} 
			catch (SQLException e) {
				e.printStackTrace();
			}

		}
	public ResultSet huyen() {
		String tinh = (String) jcomboTinh.getSelectedItem();
		
		ResultSet resulthuyen = null;
		String sql = "SELECT devvn_quanhuyen.name FROM devvn_quanhuyen INNER JOIN devvn_tinhthanhpho ON devvn_quanhuyen.matp = devvn_tinhthanhpho.matp AND"
				+ " devvn_tinhthanhpho.name ='"+tinh+"' ";
		try {
			Statement statement = (Statement) connect.createStatement();
			return statement.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resulthuyen;
	}

	public void updateDataxa(ResultSet resultxa) {
		Vector<String> dataxa = new Vector<String>();
		try {
			while (resultxa.next()) {
			dataxa.addElement(resultxa.getString(1));
			jcomboXa.setModel(new DefaultComboBoxModel<>(dataxa));
				
			}} 
			catch (SQLException e) {
				e.printStackTrace();
			}

		}
	public ResultSet xa() {
		String huyen = (String) jcomboHuyen.getSelectedItem();
		
		ResultSet resultxa = null;
		String sql = "SELECT devvn_xaphuongthitran.name FROM devvn_xaphuongthitran INNER JOIN devvn_quanhuyen ON devvn_xaphuongthitran.maqh = devvn_quanhuyen.maqh AND"
				+ " devvn_quanhuyen.name ='"+huyen+"' ";
		try {
			Statement statement = (Statement) connect.createStatement();
			return statement.executeQuery(sql);
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return resultxa;
	}



	public void windows() {
		this.setSize(1300, 678);
		this.setLocationRelativeTo(null);

		this.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		this.setVisible(true);
		jcomboTinh.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				updateDatahuyen(huyen());
			}
		});
		jcomboHuyen.addActionListener(new ActionListener(){
			public void actionPerformed(ActionEvent e) {
				updateDataxa(xa());
			}
		});
	}

	
}