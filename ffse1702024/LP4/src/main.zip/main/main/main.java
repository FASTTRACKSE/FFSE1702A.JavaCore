package main.main;

import Giaodien.ui.DesktopUI;

public class main {
		public static void main (String[] args) {
			DesktopUI desktopUI = new DesktopUI("ccc");
			desktopUI.windows();
		}
		}

